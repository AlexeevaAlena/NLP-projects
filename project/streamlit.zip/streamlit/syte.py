import streamlit as st
from typing import Dict, Any
from pathlib import Path


@st.cache_resource(show_spinner=False)
def load_backend():
    import main
    return main


def get_answer(question: str) -> str:
    backend = load_backend()
    state: Dict[str, Any] = {
        "question": question,
        "generation": None,
        "max_retries": 2
    }
    result = backend.graph.invoke(state)
    return result.get("generation", "Ответ не получен.")


def init_session_state():
    if "history" not in st.session_state:
        st.session_state.history = []


def render_chat_history():
    for message in st.session_state.history:
        role = message.get("role")
        content = message.get("content", "")
        with st.chat_message("user" if role == "user" else "assistant"):
            st.markdown(content)


def run_app():
    st.set_page_config(page_title="Помощник абитуриента", page_icon="🎓")

    logo_path = Path(__file__).with_name("RANEPA_logo.png")
    if logo_path.exists():
        left, center, right = st.columns([1, 2, 1])
        with center:
            st.image(str(logo_path), width="stretch")

    st.markdown(
        "<h1 style='text-align: center; margin-bottom: 0.25rem;'>Помощник абитуриента</h1>",
        unsafe_allow_html=True,
    )
    st.write(
        "Задайте вопрос о поступлении, программах обучения, документах или студенческой жизни."
    )

    init_session_state()

    if st.session_state.history:
        render_chat_history()

    with st.sidebar:
        if st.button("🗑️ Очистить историю", use_container_width=True):
            st.session_state.history = []
            st.rerun()

    user_input = st.chat_input(
        "Введите ваш вопрос",
    )

    if user_input and user_input.strip():
        question = user_input.strip()

        with st.spinner("Генерируется ответ..."):
            try:
                answer_text = get_answer(question)
            except Exception as e:
                answer_text = f"Ошибка: {type(e).__name__}: {e}"

        st.session_state.history.append({"role": "user", "content": question})
        st.session_state.history.append({"role": "assistant", "content": answer_text})
        st.rerun()


if __name__ == "__main__":
    run_app()